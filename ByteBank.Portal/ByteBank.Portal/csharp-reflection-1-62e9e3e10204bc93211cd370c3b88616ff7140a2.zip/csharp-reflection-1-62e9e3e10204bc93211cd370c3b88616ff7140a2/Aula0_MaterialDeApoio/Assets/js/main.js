(function() {
    alert(true);
})()